// Xbox Cloud Gaming proxy: serves the UI and relays HTTP / WebSocket traffic.
// No dependencies; needs Node 18+.
'use strict';
const http = require('http');
const https = require('https');
const net = require('net');
const tls = require('tls');
const fs = require('fs');
const path = require('path');
const SJ = require('./public/__sj/rewrite.js');

const crypto = require('crypto');
const zlib = require('zlib');
const VERSION = '2026.11.16c';

// Microsoft sign-in pages: passkeys can never work through a proxy (they are
// bound to the real site's domain), and when the page thinks they can, it
// sends Outlook/Hotmail accounts to a passkey page that just sits there.
// The pages' own settings are switched off here, on the server, so this holds
// even if a browser still runs an older copy of the proxy's scripts.
const MS_LOGIN_HOST = /^login\.(live|microsoft|microsoftonline)\.com$/;
const PASSKEY_FLAGS = /"(fIsFidoSupported|fIsPasskeySupported|fShowSignInWithFidoOnUsernameView|fShowProgressForPasskeyAutofill|fIsPasskeyAutofillEnabled|fUseWebviewFidoCustomProtocol)"\s*:\s*true/g;
function decodeBody(buf, enc) {
  enc = String(enc || '').trim().toLowerCase();
  if (!enc || enc === 'identity') return buf;
  if (enc === 'gzip' || enc === 'x-gzip') return zlib.gunzipSync(buf);
  if (enc === 'deflate') { try { return zlib.inflateSync(buf); } catch { return zlib.inflateRawSync(buf); } }
  if (enc === 'br') return zlib.brotliDecompressSync(buf);
  throw new Error('unsupported encoding ' + enc);
}
const PUBLIC = path.join(__dirname, 'public');
// Optional password lock (strongly recommended when hosted at a public link).
const PASSWORD = process.env.ACCESS_PASSWORD || '';
const AUTH_TOKEN = PASSWORD ? crypto.createHmac('sha256', PASSWORD).update('xcloud-auth').digest('hex') : '';
function authed(req) {
  if (!PASSWORD) return true;
  const m = /(?:^|;\s*)sjauth=([0-9a-f]+)/.exec(req.headers.cookie || '');
  return !!m && m[1].length === AUTH_TOKEN.length && crypto.timingSafeEqual(Buffer.from(m[1]), Buffer.from(AUTH_TOKEN));
}
const LOGIN_PAGE = (msg) => `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Cloud Gaming</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0e0f10;color:#f1f3f4;font:15px system-ui,sans-serif;padding:16px}
form{width:min(340px,100%);display:grid;gap:12px}h1{font-size:22px;margin:0 0 4px}p{margin:0;color:#e57373;min-height:1em}
input,button{font:inherit;height:42px;border-radius:10px;border:1px solid #2a2d30;padding:0 14px}
input{background:#17191b;color:#f1f3f4}button{background:#107c10;color:#fff;border:0;font-weight:600;cursor:pointer}</style></head>
<body><form method="post" action="/__sj/login"><h1>Cloud Gaming</h1><input type="password" name="password" placeholder="Password" autofocus required>
<button>Unlock</button><p>${msg}</p></form></body></html>`;
// HTTPS if a certificate is configured (TLS_CERT/TLS_KEY, or certs/server.{crt,key}).
const TLS_CERT = process.env.TLS_CERT || path.join(__dirname, 'certs', 'server.crt');
const TLS_KEY = process.env.TLS_KEY || path.join(__dirname, 'certs', 'server.key');
const USE_TLS = process.env.NO_TLS !== '1' && fs.existsSync(TLS_CERT) && fs.existsSync(TLS_KEY);
const PORT = Number(process.env.PORT) || (USE_TLS ? 8443 : 8080);
// With HTTPS on, also serve plain HTTP for use on this machine: browsers treat
// http://localhost as secure, so no certificate has to be trusted there.
const LOCAL_PORT = USE_TLS ? (Number(process.env.LOCAL_PORT) || 8080) : 0;
const HOST = process.env.HOST || '0.0.0.0';
const STATIC = {
  '/': 'index.html',
  '/index.html': 'index.html',
  '/sw.js': 'sw.js',
  '/__sj/rewrite.js': '__sj/rewrite.js',
  '/__sj/client.js': '__sj/client.js',
};
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };

// Optional upstream proxy (UPSTREAM_PROXY=http://host:port), e.g. on networks
// that only allow outbound traffic through a proxy.
const UPSTREAM = process.env.UPSTREAM_PROXY ? new URL(process.env.UPSTREAM_PROXY) : null;
function tunnelSocket(host, port, cb) {
  const r = http.request({ host: UPSTREAM.hostname, port: UPSTREAM.port || 80, method: 'CONNECT', path: `${host}:${port}`, headers: { host: `${host}:${port}` } });
  r.once('connect', (res, sock) => (res.statusCode === 200 ? cb(null, sock) : (sock.destroy(), cb(new Error('upstream proxy refused ' + host + ': ' + res.statusCode)))));
  r.once('error', cb);
  r.end();
}
const upstreamAgent = UPSTREAM && new https.Agent({ keepAlive: true });
if (upstreamAgent) upstreamAgent.createConnection = (opts, cb) => {
  tunnelSocket(opts.host, opts.port || 443, (err, sock) => {
    if (err) return cb(err);
    const t = tls.connect({ socket: sock, servername: opts.servername || opts.host });
    t.once('secureConnect', () => cb(null, t));
    t.once('error', cb);
  });
};

// Big responses (Microsoft sign-in sets many large cookies) exceed Node's
// default 16 KB header limit, so allow much more.
const MAX_HEADER = 1024 * 1024;

// ---- Server-side cookie jar --------------------------------------------
// HttpOnly cookies (the large sign-in tokens, which page scripts can't read
// anyway) live here, keyed by a small per-browser session cookie, instead of
// riding along on every request the browser makes. Saved to data/ so a
// restart doesn't sign you out.
const DATA_DIR = process.env.XCLOUD_DATA || path.join(__dirname, 'data');
const JAR_FILE = path.join(DATA_DIR, 'cookies.json');
const SESSION_TTL = 60 * 24 * 3600 * 1000;
let jars = {};
try { jars = JSON.parse(fs.readFileSync(JAR_FILE, 'utf8')) || {}; } catch { jars = {}; }
let saveTimer = null;
function saveJars() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      const now = Date.now();
      for (const [sid, j] of Object.entries(jars)) {
        j.c = j.c.filter((c) => !c.exp || c.exp > now);
        if (now - j.t > SESSION_TTL) delete jars[sid];
      }
      fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(JAR_FILE + '.tmp', JSON.stringify(jars), { mode: 0o600 });
      fs.renameSync(JAR_FILE + '.tmp', JAR_FILE);
    } catch (e) { console.log('[cookies] could not save:', e.message); }
  }, 500);
}
function sessionOf(req) {
  const m = /(?:^|;\s*)sjsid=([0-9a-f]{32})(?:;|$)/.exec(req.headers.cookie || '');
  return m ? m[1] : null;
}
function newSession() { return crypto.randomBytes(16).toString('hex'); }
const sessionCookie = (sid, secure) => `sjsid=${sid}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000${secure ? '; Secure' : ''}`;
function domainOk(host, c) { return c.hostOnly ? host === c.domain : host === c.domain || host.endsWith('.' + c.domain); }
function pathOk(reqPath, cp) { return reqPath === cp || reqPath.startsWith(cp.endsWith('/') ? cp : cp + '/'); }
function jarHeader(sid, target) {
  const j = sid && jars[sid];
  if (!j) return '';
  // (The Secure flag isn't enforced: targets are reached by this server, and
  // the browser-side cookies never enforced it either.)
  const now = Date.now(), host = target.hostname.toLowerCase();
  return j.c.filter((c) => (!c.exp || c.exp > now) && domainOk(host, c) && pathOk(target.pathname, c.path))
    .sort((a, b) => b.path.length - a.path.length)
    .map((c) => c.name + '=' + c.value).join('; ');
}
// Returns true if the cookie was taken into the server jar.
function jarStore(sid, str, target) {
  const parts = String(str).split(';');
  const first = parts.shift();
  const eq = first.indexOf('=');
  if (eq < 1) return false;
  const name = first.slice(0, eq).trim(), value = first.slice(eq + 1).trim();
  const host = target.hostname.toLowerCase();
  let domain = null, cpath = null, exp = null, maxAge = null, httpOnly = false, secure = false;
  for (const p of parts) {
    const t = p.trim(), k = t.indexOf('=');
    const an = (k < 0 ? t : t.slice(0, k)).toLowerCase(), av = k < 0 ? '' : t.slice(k + 1).trim();
    if (an === 'domain' && av) domain = av.replace(/^\./, '').toLowerCase();
    else if (an === 'path' && av.startsWith('/')) cpath = av;
    else if (an === 'expires') { const d = Date.parse(av); if (!isNaN(d)) exp = d; }
    else if (an === 'max-age') { const n = parseInt(av, 10); if (!isNaN(n)) maxAge = n; }
    else if (an === 'httponly') httpOnly = true;
    else if (an === 'secure') secure = true;
  }
  if (domain && !(host === domain || host.endsWith('.' + domain))) return true; // foreign domain: drop
  if (!cpath) { const dir = target.pathname.slice(0, target.pathname.lastIndexOf('/')); cpath = dir || '/'; }
  if (maxAge != null) exp = Date.now() + maxAge * 1000;
  const dom = domain || host;
  const j = jars[sid] || (jars[sid] = { t: Date.now(), c: [] });
  j.t = Date.now();
  const before = j.c.length;
  j.c = j.c.filter((c) => !(c.name === name && c.domain === dom && c.path === cpath));
  if (!httpOnly) { if (j.c.length !== before) saveJars(); return false; } // scripts need it: browser keeps it
  if (exp == null || exp > Date.now()) j.c.push({ name, value, domain: dom, hostOnly: !domain, path: cpath, exp, secure });
  if (j.c.length > 3000) j.c.splice(0, j.c.length - 3000);
  saveJars();
  return true;
}

const DROP_REQ = new Set(['host', 'connection', 'keep-alive', 'cookie', 'origin', 'referer', 'upgrade',
  'te', 'trailer', 'transfer-encoding', 'service-worker']);
const DROP_RES = new Set(['content-security-policy', 'content-security-policy-report-only', 'x-frame-options',
  'strict-transport-security', 'cross-origin-opener-policy', 'cross-origin-embedder-policy',
  'cross-origin-resource-policy', 'clear-site-data', 'alt-svc', 'connection', 'keep-alive', 'transfer-encoding',
  'link', 'location', 'report-to', 'nel', 'service-worker-allowed', 'set-cookie', 'permissions-policy',
  'origin-agent-cluster']);

// Shown if someone opens a /p/ URL before the service worker is installed.
const BOOT = `<!doctype html><meta charset="utf-8"><title>Loading…</title>
<p style="font:16px system-ui;margin:2rem">Starting proxy…</p>
<script>
navigator.serviceWorker.register('/sw.js', { scope: '/' })
  .then(() => navigator.serviceWorker.ready)
  .then(() => location.reload())
  .catch((e) => { document.body.textContent = 'Service workers are unavailable: ' + e; });
</script>`;

function serveStatic(res, file) {
  fs.readFile(path.join(PUBLIC, file), (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    const headers = { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache' };
    if (file === 'sw.js') headers['service-worker-allowed'] = '/';
    res.writeHead(200, headers);
    res.end(data);
  });
}

function relay(req, res, u) {
  let target;
  try {
    target = new URL(u.searchParams.get('url'));
    if (!/^https?:$/.test(target.protocol)) throw new Error();
  } catch {
    res.writeHead(400, { 'content-type': 'text/plain' });
    res.end('Bad target URL');
    return;
  }
  const secure = !!req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https';

  const headers = {};
  for (const [k, v] of Object.entries(req.headers)) {
    if (DROP_REQ.has(k) || k.startsWith('x-sj-') || k.startsWith('sec-fetch-') || k.startsWith('proxy-')) continue;
    headers[k] = v;
  }
  headers.host = target.host;
  const msLoginPage = MS_LOGIN_HOST.test(target.hostname) && /^(document|iframe|frame)$/.test(req.headers['x-sj-fetch-dest'] || '');
  if (msLoginPage) headers['accept-encoding'] = 'gzip, deflate, br'; // encodings this server can undo
  let sid = sessionOf(req);
  const freshSession = !sid;
  if (!sid) sid = newSession();
  const cookie = [SJ.filterCookies(req.headers.cookie, target.hostname), jarHeader(sid, target)].filter(Boolean).join('; ');
  if (cookie) headers.cookie = cookie;
  const ref = req.headers['x-sj-referer'];
  if (ref) headers.referer = ref;
  if (req.headers['x-sj-origin']) headers.origin = req.headers['x-sj-origin'];
  const mode = req.headers['x-sj-fetch-mode'];
  if (mode) {
    headers['sec-fetch-site'] = req.headers['x-sj-fetch-site'] || 'none';
    headers['sec-fetch-mode'] = mode;
    headers['sec-fetch-dest'] = req.headers['x-sj-fetch-dest'] || 'empty';
    if (mode === 'navigate') headers['sec-fetch-user'] = '?1';
  }

  const mod = target.protocol === 'https:' ? https : http;
  // Buffer the (small) request body so the request can be retried.
  const chunks = [];
  req.on('data', (c) => chunks.push(c));
  req.on('end', () => send(Buffer.concat(chunks), 0));

  function send(body, family) {
  let answered = false;
  const up = mod.request({
    family: family || undefined,
    autoSelectFamily: family ? undefined : true,
    autoSelectFamilyAttemptTimeout: 500,
    hostname: target.hostname.replace(/^\[|\]$/g, ''),
    port: target.port || undefined,
    method: req.method,
    path: target.pathname + target.search,
    headers,
    servername: net.isIP(target.hostname) ? undefined : target.hostname,
    agent: upstreamAgent && target.protocol === 'https:' ? upstreamAgent : undefined,
    maxHeaderSize: MAX_HEADER,
  }, (upRes) => {
    answered = true;
    const out = {};
    for (const [k, v] of Object.entries(upRes.headers)) if (!DROP_RES.has(k)) out[k] = v;
    const setCookies = [];
    if (freshSession) setCookies.push(sessionCookie(sid, secure));
    for (const c of upRes.headers['set-cookie'] || []) {
      if (jarStore(sid, c, target)) {
        // Now held server-side; drop any old browser-side copy.
        const name = c.slice(0, c.indexOf('=')).trim();
        const stale = SJ.rewriteSetCookie(name + '=x', target.hostname, false);
        if (stale) { const key = stale.slice(0, stale.indexOf('=')); if ((req.headers.cookie || '').includes(key + '=')) setCookies.push(key + '=; Max-Age=0; Path=/'); }
      } else {
        const r = SJ.rewriteSetCookie(c, target.hostname, secure);
        if (r) setCookies.push(r);
      }
    }
    if (setCookies.length) out['set-cookie'] = setCookies;
    if (upRes.statusCode >= 500) console.log(`[relay] ${upRes.statusCode} ${req.method} ${target.href.slice(0, 200)}`);
    const status = upRes.statusCode;
    if (status >= 300 && status < 400 && upRes.headers.location) {
      // Fetch from the service worker would follow a real redirect itself,
      // so describe it in headers and let the worker issue a proxied redirect.
      let loc;
      try { loc = new URL(upRes.headers.location, target).href; } catch { loc = target.href; }
      delete out['content-length'];
      delete out['content-encoding'];
      out['x-sj-location'] = loc;
      out['x-sj-status'] = String(status);
      upRes.resume();
      res.writeHead(200, out);
      res.end();
      return;
    }
    if (msLoginPage && /text\/html/i.test(upRes.headers['content-type'] || '')) {
      const parts = [];
      upRes.on('data', (c) => parts.push(c));
      upRes.on('error', () => { if (!res.headersSent) res.writeHead(502); res.end(); });
      upRes.on('end', () => {
        let body = Buffer.concat(parts);
        try {
          const html = decodeBody(body, upRes.headers['content-encoding']).toString('utf8');
          let n = 0;
          const fixed = html.replace(PASSKEY_FLAGS, (m, k) => { n++; return '"' + k + '":false'; });
          body = Buffer.from(fixed, 'utf8');
          delete out['content-encoding'];
          if (n) console.log(`[sign-in] passkeys switched off on ${target.hostname}${target.pathname} (${n} settings)`);
        } catch (e) {
          console.log(`[sign-in] couldn't adjust ${target.hostname}${target.pathname}: ${e.message}`);
        }
        out['content-length'] = String(body.length);
        res.writeHead(status, out);
        res.end(body);
      });
      return;
    }
    res.writeHead(status, out);
    upRes.pipe(res);
  });
  up.setTimeout(family ? 15000 : 20000, () => up.destroy(Object.assign(new Error('upstream timeout'), { code: 'ETIMEDOUT' })));
  up.on('error', (err) => {
    // Some machines (often Linux on Chromebooks) get IPv6 addresses they
    // can't actually reach, and the connection just hangs: retry once over IPv4.
    const retryable = /ETIMEDOUT|ECONNRESET|EHOSTUNREACH|ENETUNREACH|EADDRNOTAVAIL/.test(err.code || '');
    if (!answered && !family && retryable && !res.headersSent) {
      console.log(`[relay] ${err.code} on ${target.host}; retrying over IPv4`);
      return send(body, 4);
    }
    console.log(`[relay] failed ${req.method} ${target.href.slice(0, 200)}: ${err.code || ''} ${err.message}`);
    if (err.code === 'ETIMEDOUT') {
      console.log(`[relay]   this machine can't get an answer from ${target.host}. Test it with:  curl -v -m 15 ${target.origin}/`);
    }
    if (!res.headersSent) res.writeHead(502, { 'content-type': 'text/plain', 'x-sj-error': encodeURIComponent(`${err.message} (this server couldn't reach ${target.host})`).slice(0, 300) });
    res.end('Upstream error: ' + err.message);
  });
  up.end(body);
  }
}

// WebSocket: rewrite the handshake, then splice raw bytes both ways. The
// browser's Sec-WebSocket-Key is forwarded untouched, so the target's
// Sec-WebSocket-Accept is valid for the browser and framing needs no help.
function tunnel(req, socket, head) {
  const u = new URL(req.url, 'http://x');
  let target;
  try {
    target = new URL(u.searchParams.get('url'));
    if (!/^wss?:$/.test(target.protocol)) throw new Error();
  } catch { socket.destroy(); return; }
  const origin = u.searchParams.get('origin') || target.origin.replace(/^ws/, 'http');
  const isTls = target.protocol === 'wss:';
  const port = Number(target.port) || (isTls ? 443 : 80);
  const host = target.hostname.replace(/^\[|\]$/g, '');
  const up = isTls
    ? tls.connect({ host, port, servername: net.isIP(host) ? undefined : host })
    : net.connect(port, host);

  up.once(isTls ? 'secureConnect' : 'connect', () => {
    const lines = [`GET ${target.pathname}${target.search} HTTP/1.1`, `Host: ${target.host}`, `Origin: ${origin}`];
    for (let i = 0; i < req.rawHeaders.length; i += 2) {
      const k = req.rawHeaders[i];
      const lk = k.toLowerCase();
      if (lk === 'host' || lk === 'origin' || lk === 'cookie' || lk.startsWith('sec-fetch-')) continue;
      lines.push(`${k}: ${req.rawHeaders[i + 1]}`);
    }
    const cookie = [SJ.filterCookies(req.headers.cookie, target.hostname), jarHeader(sessionOf(req), target)].filter(Boolean).join('; ');
    if (cookie) lines.push(`Cookie: ${cookie}`);
    up.write(lines.join('\r\n') + '\r\n\r\n');
    if (head && head.length) up.write(head);
    up.pipe(socket);
    socket.pipe(up);
  });
  up.on('error', () => socket.destroy());
  socket.on('error', () => up.destroy());
  socket.on('close', () => up.destroy());
}

function handler(req, res) {
  const u = new URL(req.url, 'http://x');
  if (PASSWORD && u.pathname === '/__sj/login' && req.method === 'POST') {
    let body = '';
    req.on('data', (d) => { body += d; if (body.length > 4096) req.destroy(); });
    req.on('end', () => {
      const given = new URLSearchParams(body).get('password') || '';
      const ok = crypto.createHmac('sha256', given).update('xcloud-auth').digest('hex') === AUTH_TOKEN;
      if (!ok) { res.writeHead(401, { 'content-type': 'text/html; charset=utf-8' }); res.end(LOGIN_PAGE('Wrong password')); return; }
      const secure = !!req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https';
      res.writeHead(303, { location: '/', 'set-cookie': `sjauth=${AUTH_TOKEN}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000${secure ? '; Secure' : ''}` });
      res.end();
    });
    return;
  }
  if (!authed(req)) {
    if (u.pathname === '/__sj/relay' || u.pathname === '/sw.js' || u.pathname.startsWith('/__sj/')) { res.writeHead(401); res.end('Locked'); return; }
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    res.end(LOGIN_PAGE(''));
    return;
  }
  if (u.pathname === '/__sj/relay') return relay(req, res, u);
  if (u.pathname === '/__sj/version') { res.writeHead(200, { 'content-type': 'text/plain', 'cache-control': 'no-store' }); res.end(VERSION); return; }
  if (u.pathname === '/__sj/clear' && req.method === 'POST') {
    // Sign out: expire every proxied cookie this browser holds.
    const sid = sessionOf(req);
    if (sid && jars[sid]) { delete jars[sid]; saveJars(); }
    const names = String(req.headers.cookie || '').split(/;\s*/).map((c) => c.split('=')[0]).filter((n) => n && n !== 'sjauth' && n !== 'sjsid');
    res.writeHead(200, { 'content-type': 'application/json', 'set-cookie': names.map((n) => `${n}=; Max-Age=0; Path=/`) });
    res.end(JSON.stringify({ cleared: names.length }));
    return;
  }
  if (STATIC[u.pathname]) return serveStatic(res, STATIC[u.pathname]);
  if (u.pathname === '/ca.crt' && USE_TLS) {
    // The public CA certificate, so other devices can install it easily.
    return fs.readFile(path.join(path.dirname(TLS_CERT), 'ca.crt'), (err, data) => {
      if (err) { res.writeHead(404); res.end('No CA certificate'); return; }
      res.writeHead(200, { 'content-type': 'application/x-x509-ca-cert', 'content-disposition': 'attachment; filename="ca.crt"' });
      res.end(data);
    });
  }
  if (u.pathname.startsWith(SJ.PREFIX)) {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    res.end(BOOT);
    return;
  }
  res.writeHead(404, { 'content-type': 'text/plain' });
  res.end('Not found');
}

const server = USE_TLS
  ? https.createServer({ cert: fs.readFileSync(TLS_CERT), key: fs.readFileSync(TLS_KEY), maxHeaderSize: MAX_HEADER }, handler)
  : http.createServer({ maxHeaderSize: MAX_HEADER }, handler);
const localServer = LOCAL_PORT ? http.createServer({ maxHeaderSize: MAX_HEADER }, handler) : null;
function onUpgrade(req, socket, head) {
  if (!authed(req)) { socket.destroy(); return; }
  if (new URL(req.url, 'http://x').pathname === '/__sj/ws') tunnel(req, socket, head);
  else socket.destroy();
}
server.on('upgrade', onUpgrade);
if (localServer) localServer.on('upgrade', onUpgrade);

if (require.main === module) {
  const ips = Object.values(require('os').networkInterfaces()).flat()
    .filter((a) => a && a.family === 'IPv4' && !a.internal).map((a) => a.address);
  const started = () => {
    console.log(`Xbox Cloud Gaming proxy v${VERSION} running` + (PASSWORD ? ' (password protected)' : ''));
    if (USE_TLS) {
      if (localServer && localServer.listening) console.log(`  on this machine: http://localhost:${LOCAL_PORT}   <- use this here, no certificate needed`);
      else console.log(`  on this machine: https://localhost:${PORT}`);
      for (const ip of ips) console.log(`  other devices:   https://${ip}:${PORT}   (they must trust ca.crt)`);
    } else {
      console.log(`  on this machine: http://localhost:${PORT}`);
      for (const ip of ips) console.log(`  other devices:   http://${ip}:${PORT}   (won't work: needs HTTPS; run xcloud.sh without --http)`);
    }
  };
  server.once('error', (e) => {
    if (e.code === 'EADDRINUSE') {
      console.log(`\nPort ${PORT} is already in use, so this copy (v${VERSION}) did NOT start.`);
      console.log('An older copy of the proxy is probably still running and serving the old version.');
      console.log('Stop it first: press Ctrl+C in its window, or run  sudo systemctl stop xcloud  if you');
      console.log('installed it as a service (or  sudo ./xcloud.sh --service  again to update the service).');
      process.exit(1);
    }
    throw e;
  });
  server.listen(PORT, HOST, () => {
    if (!localServer) return started();
    localServer.once('error', (e) => { console.log(`  (couldn't open http port ${LOCAL_PORT}: ${e.code}; set LOCAL_PORT to another port)`); started(); });
    localServer.listen(LOCAL_PORT, HOST, started);
  });
}
module.exports = server;
