Xbox Cloud Gaming proxy
=======================

This is a program that has to RUN on a machine. Uploading these files to a
file host or a static site (GitHub Pages, Netlify Drop, Google Drive, ...)
will only show an empty page, because there is no server running behind it.

Pick one of the two ways below.


OPTION A - Your own Linux machine (xcloud.sh)
---------------------------------------------
  chmod +x xcloud.sh
  ./xcloud.sh --password=choose-a-password

Then open it in Chrome or Edge:

  - On the Linux machine itself:  http://localhost:8080
    (no certificate needed - use this, not https://localhost:8443)
  - From other devices:           https://<machine-ip>:8443
    (needs the certificate step below)

The first run downloads Node.js if needed, writes the app into
./xcloud-app, makes an HTTPS certificate, and starts the server.

  ./xcloud.sh 9000                       use a different port
  sudo ./xcloud.sh --service --password=X  start automatically on boot
  sudo ./xcloud.sh --uninstall
  ./xcloud.sh --http                     plain HTTP (only works on the machine itself)

Playing from another device (not needed on the Linux machine): download https://<address>:8443/ca.crt on
that device and install it as a trusted root certificate authority (the
script prints steps). Clicking past the browser warning is not enough.


OPTION B - A link from a hosting service (folder: xcloud-hosted)
----------------------------------------------------------------
Use a host that RUNS Node.js apps, for example Render ("Web Service"),
Railway, Fly.io, or any VPS. Static-site hosts will not work.

  1. Put the contents of the xcloud-hosted folder in a GitHub repository
     (or upload it, if your host allows that).
  2. Create a Node.js web service from it:
       Build command: (none needed)    Start command: npm start
  3. Add an environment variable:   ACCESS_PASSWORD = choose-a-password
     (Without it, anyone who finds your link can use it.)
  4. Open the https link the host gives you and enter the password.

The host provides HTTPS and the PORT automatically; there is nothing to
install. Free tiers usually go to sleep when idle, so the first load can
take up to a minute.


If something doesn't work
--------------------------
An orange "Problems" button appears in the top bar when a request fails
or a page hits an error. Open it, press Copy, and send the list to
whoever is helping you. The server also prints failures in its terminal.

Sign-in cookies are kept on the server in the data/ folder (so they
don't overload the browser). "Sign out" in the top bar clears them.

Notes
-----
  - The game stream goes directly from your browser to Microsoft's
    servers, not through the proxy. If your network blocks them, games
    won't start.
  - Sign in with your password, an emailed code or the Authenticator app.
    Passkeys can't work through a proxy, so the sign-in page is told the
    browser doesn't support them. If Microsoft asks for a passkey anyway,
    choose "Other ways to sign in".
  - Your Microsoft password passes through the server. Use a server you
    control and always set a password.
  - Some hosting providers don't allow web proxies in their terms; check
    yours before deploying.
